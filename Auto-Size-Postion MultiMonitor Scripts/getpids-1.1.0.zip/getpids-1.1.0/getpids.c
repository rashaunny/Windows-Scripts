/* ######################################################################### */
/* ##                                                                     ## */
/* ##  getpids.c                                                          ## */
/* ##                                                                     ## */
/* ## ------------------------------------------------------------------- ## */
/* ##                                                                     ## */
/* ##  Job .......: Starting with the current Process ID (PID), the       ## */
/* ##               tool climbs up the process hierarchy and displays     ## */
/* ##               the parent PID, grandparent PID and so on.            ## */
/* ##                                                                     ## */
/* ## ------------------------------------------------------------------- ## */
/* ##                                                                     ## */
/* ##  Copyright (C) 2003  Daniel Scheibli                                ## */
/* ##                                                                     ## */
/* ##  This program is free software; you can redistribute it and/or      ## */
/* ##  modify it under the terms of the GNU General Public License        ## */
/* ##  as published by the Free Software Foundation; either version 2     ## */
/* ##  of the License, or (at your option) any later version.             ## */
/* ##                                                                     ## */
/* ##  This program is distributed in the hope that it will be useful,    ## */
/* ##  but WITHOUT ANY WARRANTY; without even the implied warranty of     ## */
/* ##  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the      ## */
/* ##  GNU General Public License for more details.                       ## */
/* ##                                                                     ## */
/* ##  You should have received a copy of the GNU General Public License  ## */
/* ##  along with this program; if not, write to the Free Software        ## */
/* ##  Foundation, Inc., 59 Temple Place - Suite 330, Boston,             ## */
/* ##  MA  02111-1307, USA.                                               ## */
/* ##                                                                     ## */
/* ## ------------------------------------------------------------------- ## */
/* ##                                                                     ## */
/* ##  Author ....: Daniel Scheibli <daniel@scheibli.com>                 ## */
/* ##  Date ......: 2003-01-15                                            ## */
/* ##  Changes ...: see changelog.txt                                     ## */
/* ##                                                                     ## */
/* ######################################################################### */ 

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <windows.h>

struct ProcessBasicInformation {
	DWORD ExitStatus;
	PVOID PebBaseAddress;
	DWORD AffinityMask;
	DWORD BasePriority;
	ULONG UniqueProcessId;
	ULONG InheritedFromUniqueProcessId;
};
struct KernelUserTimes {
	LONGLONG CreateTime;
	LONGLONG ExitTime;
	LONGLONG KernelTime;
	LONGLONG UserTime;
};
typedef LONG (__stdcall *FPTR_NtQueryInformationProcess) (HANDLE, INT, PVOID, ULONG, PULONG);
FPTR_NtQueryInformationProcess NtQueryInformationProcess;

// command-line parameters
ULONG starting_pid;
int display_ceased_ancestor = FALSE;

int  ParseCmdLine(int argc, char *argv[]);
int  PrintProcessHierarchy(void);
int  QueryProcess(ULONG pid, ULONG *ppid, LONGLONG *create_time);
void Usage(void);



int main(int argc, char *argv[]) {
        
    starting_pid = GetCurrentProcessId();
        
    if (ParseCmdLine(argc, argv) != 0) {
        Usage();
        return 1;
    }
    
    return PrintProcessHierarchy();
}



int ParseCmdLine(int argc, char *argv[]) {

    ULONG pid; 
    
    while (TRUE) {
        switch (getopt(argc, argv, "xp:")) {
            case 'x':   // display PID of no longer existing ancestor
                display_ceased_ancestor = TRUE;
                break;
            case 'p':   // use PID other than current process
                pid = strtoul(optarg, NULL, 10);
                if (pid == 0 && strcmp(optarg, "0") != 0) {
                    return 1;
                }
                starting_pid = pid;
                break;
            case -1:    // end of argument list
                return 0;
			case '?':   // help
            case ':':   // missing option argument
            default:    // unknown option
                return 1;
        }
    }
}



int PrintProcessHierarchy() {

	ULONG    query_pid = starting_pid;
	ULONG    query_ppid;
	LONGLONG query_create_time;
	LONGLONG child_create_time;
	int      rc;

    // Retrieve function address from DLL
    NtQueryInformationProcess = (FPTR_NtQueryInformationProcess) GetProcAddress(GetModuleHandle("ntdll"), "NtQueryInformationProcess");
    if (NtQueryInformationProcess == NULL) {
        return 1;
    }

    // In the following code we ensure that the queried parent process wasn't
    // created before the child process. 
    // This is needed, because the Windows operatoring system is extensively
    // reusing PIDs. This might lead to situations where simply following 
    // the parent PID could result in a loop (even though the actual process 
    // hierarchy doesn't contain an actual loop).

    // TODO: As Alex Ionescu pointed out in [1], we should additionally
    //       consider the possibility of a clock change. Unfortunately that
    //       requires either using undocumented data structures or using
    //       Windows 10 features.
    // [1] http://www.osronline.com/showthread.cfm?link=263748
    
	// Collect initial data for the current process
	if (QueryProcess(query_pid, &query_ppid, &query_create_time) == 1) {
	    printf("%lu", query_pid);
        query_pid = query_ppid;
        child_create_time = query_create_time;
	}
	else {
		return 1;
	}
	// Climp hierarchy and collect data for ancestors
	int loop = TRUE;
	while (loop) {
		rc = QueryProcess(query_pid, &query_ppid, &query_create_time);
		switch (rc) {
		    case 0:
		        if (display_ceased_ancestor) {
		            printf(" -%lu", query_pid);
			    }
			    loop = FALSE;
			    break;
            case 1:
                if (query_create_time < child_create_time) {
                    printf(" %lu", query_pid);
                    query_pid = query_ppid;
                    child_create_time = query_create_time;
                }
                else {
                    if (display_ceased_ancestor) {
                        printf(" -%lu", query_pid);
                    }
                    loop = FALSE;
                }
		        break;
            default:
                printf("\r\n");
    			return 1;
		}
	}
    printf("\r\n");
	
	return 0;
}



// Collects PPID and process creation time for a given PID.
int QueryProcess(ULONG pid, ULONG *ppid, LONGLONG *create_time) {

	HANDLE process_handle = NULL;
	struct ProcessBasicInformation process_info;
	struct KernelUserTimes	       process_time;
    
	process_handle = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, pid);
	if (process_handle == NULL) {
		return 0;
	}
	if (NtQueryInformationProcess(process_handle, 0, (void *) &process_info, sizeof(process_info), NULL) != 0) {
		CloseHandle(process_handle);
		return -1;
	}
	if (NtQueryInformationProcess(process_handle, 4, (void *) &process_time, sizeof(process_time), NULL) != 0) {
		CloseHandle(process_handle);
		return -1;
	}
	CloseHandle(process_handle);
	*ppid        = process_info.InheritedFromUniqueProcessId;
	*create_time = process_time.CreateTime;
	
	return 1;
}



void Usage(void) {
    fprintf(stderr, "\r\n");
    fprintf(stderr, "USAGE: getpids [OPTIONS]\r\n");
    fprintf(stderr, "\r\n");
    fprintf(stderr, "    -p PID  Specifies the PID to be used as starting point.\r\n");
    fprintf(stderr, "            Default is the PID of getpids itself is used.\r\n");
    fprintf(stderr, "\r\n");
    fprintf(stderr, "    -x      Shows the PID of a longer existing ancestor.\r\n");
    fprintf(stderr, "            Given the default output A B C, the altered output\r\n");
    fprintf(stderr, "            becomes A B C -D (please note the leading dash in\r\n");
    fprintf(stderr, "            front of the no longer existing ancestor's PID).\r\n");
    fprintf(stderr, "            Default is to not show the PID of ceased ancestors.\r\n");
    fprintf(stderr, "\r\n");
}



// vim:tabstop=4:softtabstop=4:shiftwidth=4:expandtab
